import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryRed = Color(0xFFB71C1C);
  static const Color lightGray = Color(0xFFF5F5F5);
  static const Color darkGray = Color(0xFF757575);
  static const Color white = Colors.white;
  static const Color black = Colors.black;
}
