package com.example.spartrack

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
